
//$(document).ready(function(){
	
	// 저장된 쿠키값을 가져와서 ID 칸에 넣어준다. 없으면 공백으로 들어감.
//	var userInputId = getCookie("userInputId");
//	$("input[name='id']").val(userInputId);
//	
//	// 그 전에 ID를 저장해서 처음 페이지 로딩 시, 입력 칸에 저장된 ID가 표시된 상태라면,
//	if($("input[name='id']").val() != ""){ 
//		
//		// ID 저장하기를 체크 상태로 두기.
//		$("#idSaveCheck").attr("checked", true); 
//	}
//	
//	// 체크박스에 변화가 있다면,
//	$("#idSaveCheck").change(function() { 
//		
//		// ID 저장하기 체크했을 때
//		if($("#idSaveCheck").is(":checked")) { 
//			var userInputId = $("input[name='id']").val();
//			
//			// 7일 동안 쿠키 보관
//			setCookie("userInputId", userInputId, 7); 
//			
//		// ID 저장하기 체크 해제 시
//		} else { 
//            deleteCookie("userInputId");
//        }
//	});
//	
//	// ID 저장하기를 체크한 상태에서 ID를 입력하는 경우, 이럴 때도 쿠키 저장.
//	// ID 입력 칸에 ID를 입력할 때
//	$("input[name='id']").keyup(function() {
//		
//		// ID 저장하기를 체크한 상태라면
//		if($("#idSaveCheck").is(":checked")) { 
//			var userInputId = $("input[name='id']").val();
//			
//			// 7일 동안 쿠키 보관
//			setCookie("userInputId", userInputId, 7); 
//		}
//	});
//});
(function ($) {
	
	/**
	 * Form Object 직렬화 (JSON 형태로 변환하기 위함)
	 */
	$.fn.serializeObject = function() {
	    var o = {};
	    var a = this.serializeArray();
	    
	    $.each(a, function() {
	        if (o[this.name] || o[this.name] == '') {
	            if (!o[this.name].push) {
	                o[this.name] = [o[this.name]];
	            }
	            o[this.name].push(this.value || '');
	            
	        } else {
	            o[this.name] = this.value || '';
	        }
	    });
	    return o;
	};
	
	/**
	 * 서버통신 공통함수 (비동기 통신일 경우)
	 */
	$.ajaxHttpReqest = function(temurl, type, param, callback) {
    	$.ajax({
    		url : temurl,
    		type : type,
    		data : param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},
    		success : function(data) {
		    	if (callback != '') {
	    		callback(data);
	    	}
    			
    		}, error : function(request,status,error) {
    			alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
    		}
    	});		
		
	};
	
	/**
	 * 서버통신 공통함수 (동기 통신일 경우)
	 */
	$.ajaxSyncHttpReqest = function(temurl, type, param) {
		var result = "";
		
		$.ajax({
    		url : temurl,
    		type : type,
		    data: param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},
		    async: false,
		    success: function(data) {
		    	result = data;
		    },
		    error: function(e){
		        alert(e.status);
		    }
		});
		return result;
	};	
	
	// 
	/**
	 * 콤보 공통함수
	 */
	$.ajaxComboListHttpReqest = function(temurl, param, target, findChar, findValue, findText, eqValue) {
		$.ajax({
    		url : temurl,
    		type : type,
		    data: param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},	    
		    success: function(res) {
			   var data="<option value=''>전체</option>";
			   
			   $(res).find(findChar).each(function() {
					value = $(this).find(findValue).attr('value');
					text  = $(this).find(findText).attr('value');
					
					if (value != eqValue) {
						data += "<option value='"+value+"'>"+text+"</option>";
						
					} else {
						data += "<option value='"+value+"' selected >"+text+"</option>";
					}
			   });

			   $(target).empty();
			   $(target).append(data);
			   
				// label text 변경
				$(target).siblings('label').text($(target).children('option:selected').text());			   
		    },
		    error: function(e){
		        alert(e.responseText);
		    }
		});
	};	
	
	
	/**
	 * 파일업로드 공통함수
	 */
	$.ajaxFileUploadHttpReqest = function(temurl, formId, callback) {
		var form = new FormData($('#'+ formId)[0]);
		
		$.ajax({
			url: temurl,
			data: form,
			processData: false,
			contentType: false,
			type: 'POST',
			
		    success: function(res) {
		    	if (callback != '') {
		    		callback(res);
		    	}
		    },
		    error: function(error) {
		    	alert('에러: '+ error.status+', '+error.statusText);
		    }			
		});			
	};
})(jQuery);


/**
 *  쿠키를 이용하여 ID를 저장한다.
 *  
 * @param cookieName
 * @param value
 * @param exdays
 * @returns
 */
function setCookie(cookieName, value, exdays) {
//    var exdate = new Date();
//
//    exdate.setDate(exdate.getDate() + exdays);
//    var cookieValue = escape(value) + ((exdays==null) ? "" : "; expires=" + exdate.toGMTString());
//    document.cookie = cookieName + "=" + cookieValue;
	
	$.cookie(cookieName, value, { expires : exdays, path : '/' });
}

/**
 * 쿠키에 저장된 ID를 제거한다.
 * 
 * @param cookieName
 * @returns
 */
function deleteCookie(cookieName) {
//    var expireDate = new Date();
//
//    expireDate.setDate(expireDate.getDate() - 1);
//    document.cookie = cookieName + "= " + "; expires=" + expireDate.toGMTString();
	
//	$.cookie(cookieName, null);
	$.removeCookie(cookieName, { path: '/' });    
}

/**
 * 쿠키를 얻어온다.
 * 
 * @param cookieName
 * @returns
 */
function getCookie(cookieName) {
//    cookieName = cookieName + '=';
//
//    var cookieData = document.cookie;
//    var start = cookieData.indexOf(cookieName);
//
//    var cookieValue = '';
//
//    if(start != -1){
//        start += cookieName.length;
//        
//        var end = cookieData.indexOf(';', start);
//        if(end == -1) end = cookieData.length;
//
//        cookieValue = cookieData.substring(start, end);
//    }
//    return unescape(cookieValue);
	
	  return unescape($.cookie(cookieName));
}
