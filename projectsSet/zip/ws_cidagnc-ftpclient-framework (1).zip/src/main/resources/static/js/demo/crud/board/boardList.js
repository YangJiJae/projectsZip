
$(document).ready(function() {
	
	// 검색버튼이 눌렸을 경우
	$("#btn_sch").bind('click', function() {
		$("#btnSearchGubn").val("Y");
		
		$("#searchForm").attr("target", "_self");
		$("#searchForm").attr("action", "/demo/boardList.do");
	   	$("#searchForm").submit();						
	});
	
	// 등록버튼이 눌렸을 경우
	$("#btn_reg").bind("click", function() {
		var thisForm = document.getElementById("listForm");
		var popWin = window.open("", "objRegistPop", 
			+ "toolbar=no,status=no,menubar=no,location=no,directories=no,"
			+ "scrollbars=no,resizable=no,width=900,height=680,top=100,left=100");

	    thisForm.target = "objRegistPop";					
		thisForm.action = "/demo/boardRegForm.do";
	    thisForm.submit();			    

		popWin.focus();					
	});				
});		

// 상세 버튼이 눌렸을 경우
fn_detail = function (seq) {
	var thisForm = document.getElementById("listForm");
	var popWin = window.open("", "objDetailPop", 
		+ "toolbar=no,status=no,menubar=no,location=no,directories=no,"
		+ "scrollbars=no,resizable=no,width=900,height=680,top=100,left=100");

    thisForm.target = "objDetailPop";	
    thisForm.seq.value = seq;
    
	thisForm.action = "/demo/boardModifyForm.do";
    thisForm.submit();			    

	popWin.focus();				
};

// 페이징처리 : 페이지 이동
fn_movePage = function (pageIndex) {
	$('#searchForm').attr("id", "listForm");
	
	$("#btnSearchGubn").val("Y");
	$("#pageIndex").val(pageIndex);
	$("#pageSize").val(10);
	
	$("#listForm").attr("target", "_self");
	$("#listForm").attr("action", "/demo/boardList.do");
   	$("#listForm").submit();	
};