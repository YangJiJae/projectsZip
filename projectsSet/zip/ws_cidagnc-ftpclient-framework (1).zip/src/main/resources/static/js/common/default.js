
(function ($) {
	
	/**
	 * Form Object 직렬화 (JSON 형태로 변환하기 위함)
	 */
	$.fn.serializeObject = function() {
	    var o = {};
	    var a = this.serializeArray();
	    
	    $.each(a, function() {
	        if (o[this.name] || o[this.name] == '') {
	            if (!o[this.name].push) {
	                o[this.name] = [o[this.name]];
	            }
	            o[this.name].push(this.value || '');
	            
	        } else {
	            o[this.name] = this.value || '';
	        }
	    });
	    return o;
	};
	
	/**
	 * 서버통신 공통함수 (비동기 통신일 경우)
	 */
	$.ajaxHttpReqest = function(temurl, type, param, callback) {
    	$.ajax({
    		url : temurl,
    		type : type,
    		data : param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},
    		success : function(data) {
		    	if (callback != '') {
	    		callback(data);
	    	}
    			
    		}, error : function(request,status,error) {
    			alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
    		}
    	});		
		
	};
	
	/**
	 * 서버통신 공통함수 (동기 통신일 경우)
	 */
	$.ajaxSyncHttpReqest = function(temurl, type, param) {
		var result = "";
		
		$.ajax({
    		url : temurl,
    		type : type,
		    data: param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},
		    async: false,
		    success: function(data) {
		    	result = data;
		    },
		    error: function(e){
		        alert(e.status);
		    }
		});
		return result;
	};	
	
	// 
	/**
	 * 콤보 공통함수
	 */
	$.ajaxComboListHttpReqest = function(temurl, param, target, findChar, findValue, findText, eqValue) {
		$.ajax({
    		url : temurl,
    		type : type,
		    data: param,
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},	    
		    success: function(res) {
			   var data="<option value=''>전체</option>";
			   
			   $(res).find(findChar).each(function() {
					value = $(this).find(findValue).attr('value');
					text  = $(this).find(findText).attr('value');
					
					if (value != eqValue) {
						data += "<option value='"+value+"'>"+text+"</option>";
						
					} else {
						data += "<option value='"+value+"' selected >"+text+"</option>";
					}
			   });

			   $(target).empty();
			   $(target).append(data);
			   
				// label text 변경
				$(target).siblings('label').text($(target).children('option:selected').text());			   
		    },
		    error: function(e){
		        alert(e.responseText);
		    }
		});
	};	
	
	
	/**
	 * 파일업로드 공통함수
	 */
	$.ajaxFileUploadHttpReqest = function(temurl, formId, callback) {
		var form = new FormData($('#'+ formId)[0]);
		
		$.ajax({
			url: temurl,
			data: form,
			processData: false,
			contentType: false,
			type: 'POST',
			
		    success: function(res) {
		    	if (callback != '') {
		    		callback(res);
		    	}
		    },
		    error: function(error) {
		    	alert('에러: '+ error.status+', '+error.statusText);
		    }			
		});			
	};
})(jQuery);