
$(document).ready(function() {
	$.validator.setDefaults({
		onkeyup:false,
		onclick:false,
		onfocusout:false,
		showErrors:function(errorMap, errorList){
			if(this.numberOfInvalids()) {
				alert(errorList[0].message);
				$(errorList[0].element).focus();
            }
		}
	});	

	// 커스텀 : 이메일 형식 확인
	$.validator.addMethod("customEmail", function(value, element) {
		return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);
		              
	}, '올바른 이메일 주소를 입력해 주세요'); 					
	
		// 커스텀 : 이름에서 관리자 문자열 존재확인
		$.validator.addMethod("customAdmin", function(value, element) {
			 return /^((?!관리자).)*$/i.test(value);
			 
		}, "관리자로 등록이 불가능합니다.");				
	
	// 커스텀 : 제목 또는 내용에서 비속어 문자열 존재확인
	$.validator.addMethod("customSlangExistChk", function(value, element) {
		 return fnSlangExistChk(value);
		 
	}, "제목 또는 내용에 비속어가 포함되어 등록이 불가능 합니다.");				
	
	// 유효성 검사
	$("#modifyForm").validate({
	    rules:{
	    	regrNm: {required:true, customAdmin: true, maxlength: 50},
	        email:{required:true, customEmail: true, maxlength: 100},		
//	        passwd:{required:true, rangelength: [4, 12]},
	    	title: {required:true, customSlangExistChk: true, maxlength: 200}, 
	    	content: {required:true, customSlangExistChk: true, maxlength: 4000}
	    },
	    messages:{ 
	    	regrNm:{
	            required:"이름을 입력해 주세요",
	            maxlength: $.validator.format('{0}자 내로 입력하세요.')
	        },
	        email:{
	            required:"Email을 입력해 주세요",
	            email:"올바른 이메일 주소를 입력해 주세요",
	            maxlength: $.validator.format('{0}자 내로 입력하세요.')
	        },
//	        passwd:{
//	            required:"비밀번호를 입력해 주세요",
//	            rangelength: $.validator.format('{0}자 이상 {1}자 이내로 입력하셔야 합니다.')
//	        },				    	
	    	title:{
	            required:"제목을 입력해 주세요",
	            maxlength: $.validator.format('{0}자 내로 입력하세요.')
	        },
	        content:{
	            required:"내용을 입력해 주세요",
	            maxlength: $.validator.format('{0}자 내로 입력하세요.')
	        }       
	    },
	    submitHandler:function(form) {
		    var param = $("#modifyForm").serializeObject();
		    	
	    	// XSS 공격에 대한 스크립트 문자열 존재시 escaping 시킨다.
	    	param.title = fnXSSfilter(param.title);
	    	param.content = fnReplaceCarigeToBr(fnXSSfilter(param.content));	

	    	$.ajax({
	    		url : "/demo/updateBoard.do",
	    		type : "POST",
				data : JSON.stringify(param),
	    		beforeSend : function(xhr) {
	    			xhr.setRequestHeader("Content-Type", "application/json");
	    			xhr.setRequestHeader("Accept", "application/json");
	    		},
	    		success : function(data) {
	    			var isSuccess = data.isSuccess || false;
	    			var resultMsg = data.resultMsg;
	    			
	    			if(isSuccess == true) {
						$("#btn_sch", opener.document).trigger('click');					
						$("#btn_close").trigger('click');
	    				
	    			} else {
	    				return false;
	    			}
	    			alert(resultMsg);
	    			
	    		}, error : function(request,status,error) {
	    			alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
	    		}
	    	});
	    }
	});	
	
	// 수정버튼이 눌렸을 경우
	$("#btn_chg").bind('click', function(e) {
		e.preventDefault();
		$("#modifyForm").submit();				
	});
	
	// 삭제 버튼이 눌렸을 경우
	$("#btn_del").bind('click', function() {
		$.ajax({
    		url : "/demo/deleteBoard.do",
    		type : "GET",
			data : {seq: $("#seq").val()},
    		beforeSend : function(xhr) {
    			xhr.setRequestHeader("Content-Type", "application/json");
    			xhr.setRequestHeader("Accept", "application/json");
    		},
			contentType : "application/json",
			dataType : 'json',

    		success : function(data) {
    			var isSuccess = data.isSuccess || false;
    			var resultMsg = data.resultMsg;
    			
    			if(isSuccess == true) {
					$("#btn_sch", opener.document).trigger('click');					
					$("#btn_close").trigger('click');
    				
    			} else {
    				return false;
    			}
    			alert(resultMsg);
    		}, 
    		error : function(request,status,error) {
    			alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
    		}
    	});						
	});
	
	// 닫기버튼이 눌렸을 경우
	$("#btn_close").bind("click", function(e) {	
		e.preventDefault();
		self.close();	    
	});					
});

$(function() {
	$("#title").val(fnReplaceHtmlTag($("#title").val()));
	$("#content").val(fnReplaceBrToCarige(fnReplaceHtmlTag($("#content").val())));
});

/**
 * 비속어 존재여부 검사
 * @returns
 */
function fnSlangExistChk(value) {
	var isSuccess = true;
	
    var slangList = new Array('10새','10새기','10새리','10세리','10쉐이','10쉑','10스','10쌔', '10쌔기','10쎄','10알','10창','10탱','18것','18넘','18년','18노','18놈','18뇬','18럼','18롬','18새','18새끼','18색','18세끼','18세리','18섹','18쉑','18스','18아','ㄱㅐ','ㄲㅏ','ㄲㅑ','ㄲㅣ',
    		'ㅅㅂㄹㅁ','ㅅㅐ','ㅆㅂㄹㅁ','ㅆㅍ','ㅆㅣ','ㅆ앙','ㅍㅏ','凸','갈보','갈보년','강아지','같은년','같은뇬','개같은','개구라','개년','개놈','개뇬','개대중','개독','개돼중','개랄','개보지','개뻥','개뿔','개새','개새기','개새끼','개새키','개색기','개색끼','개색키','개색히','개섀끼','개세',
    		'개세끼','개세이','개소리','개쑈','개쇳기','개수작','개쉐','개쉐리','개쉐이','개쉑','개쉽','개스끼','개시키','개십새기','개십새끼','개쐑','개씹','개아들','개자슥','개자지','개접','개좆','개좌식','개허접','걔새','걔수작','걔시끼','걔시키','걔썌','걸레','게색기','게색끼','광뇬','구녕',
    		'구라','구멍','그년','그새끼','냄비','놈현','뇬','눈깔','뉘미럴','니귀미','니기미','니미','니미랄','니미럴','니미씹','니아배','니아베','니아비','니어매','니어메','니어미','닝기리','닝기미','대가리','뎡신','도라이','돈놈','돌아이','돌은놈','되질래','뒈져','뒈져라','뒈진','뒈진다','뒈질',
    		'뒤질래','등신','디져라','디진다','디질래','딩시','따식','때놈','또라이','똘아이','똘아이','뙈놈','뙤놈','뙨넘','뙨놈','뚜쟁','띠바','띠발','띠불','띠팔','메친넘','메친놈','미췬','미췬','미친','미친넘','미친년','미친놈','미친새끼','미친스까이','미틴','미틴넘','미틴년','미틴놈','바랄년',
    		'병자','뱅마','뱅신','벼엉신','병쉰','병신','부랄','부럴','불알','불할','붕가','붙어먹','뷰웅','븅','븅신','빌어먹','빙시','빙신','빠가','빠구리','빠굴','빠큐','뻐큐','뻑큐','뽁큐','상넘이','상놈을','상놈의','상놈이','새갸','새꺄','새끼','새새끼','새키','색끼','생쑈','세갸','세꺄','세끼','섹스',
    		'쇼하네','쉐','쉐기','쉐끼','쉐리','쉐에기','쉐키','쉑','쉣','쉨','쉬발','쉬밸','쉬벌','쉬뻘','쉬펄','쉽알','스패킹','스팽','시궁창','시끼','시댕','시뎅','시랄','시발','시벌','시부랄','시부럴','시부리','시불','시브랄','시팍','시팔','시펄','신발끈','심발끈','심탱','십8','십라','십새','십새끼',
    		'십세','십쉐','십쉐이','십스키','십쌔','십창','십탱','싶알','싸가지','싹아지','쌉년','쌍넘','쌍년','쌍놈','쌍뇬','쌔끼','쌕','쌩쑈','쌴년','썅','썅년','썅놈','썡쇼','써벌','썩을년','썩을놈','쎄꺄','쎄엑','쒸벌','쒸뻘','쒸팔','쒸펄','쓰바','쓰박','쓰발','쓰벌','쓰팔','씁새','씁얼','씌파','씨8',
    		'씨끼','씨댕','씨뎅','씨바','씨바랄','씨박','씨발','씨방','씨방새','씨방세','씨밸','씨뱅','씨벌','씨벨','씨봉','씨봉알','씨부랄','씨부럴','씨부렁','씨부리','씨불','씨붕','씨브랄','씨빠','씨빨','씨뽀랄','씨앙','씨파','씨팍','씨팔','씨펄','씸년','씸뇬','씸새끼','씹같','씹년','씹뇬','씹보지',
    		'씹새','씹새기','씹새끼','씹새리','씹세','씹쉐','씹스키','씹쌔','씹이','씹자지','씹질','씹창','씹탱','씹퇭','씹팔','씹할','씹헐','아가리','아갈','아갈이','아갈통','아구창','아구통','아굴','얌마','양넘','양년','양놈','엄창','엠병','여물통','염병','엿같','옘병','옘빙','오입','왜년','왜놈','욤병',
    		'육갑','은년','을년','이년','이새끼','이새키','이스끼','이스키','임마','자슥','잡것','잡넘','잡년','잡놈','저년','저새끼','접년','젖밥','조까','조까치','조낸','조또','조랭','조빠','조쟁이','조지냐','조진다','조찐','조질래','존나','존나게','존니','존만','존만한','좀물','좁년','좆','좁밥','좃까',
    		'좃또','좃만','좃밥','좃이','좃찐','좆같','좆까','좆나','좆또','좆만','좆밥','좆이','좆찐','좇같','좇이','좌식','주글','주글래','주데이','주뎅','주뎅이','주둥아리','주둥이','주접','주접떨','죽고잡','죽을래','죽통','쥐랄','쥐롤','쥬디','지랄','지럴','지롤','지미랄','짜식','짜아식','쪼다','쫍빱',
    		'찌랄','창녀','캐년','캐놈','캐스끼','캐스키','캐시키','탱구','팔럼','퍽큐','호로','호로놈','호로새끼','호로색','호로쉑','호로스까이','호로스키','후라들','후레자식', '후래자식','후레','후뢰','씨ㅋ발','ㅆ1발','씌발','띠발','띄발','뛰발','띠ㅋ발','뉘뮈'
    );
    var tmp;
    
    for(i=0 ; i < slangList.length ; i++){
    	tmp = value.toLowerCase().indexOf(slangList[i]);
    	
        if(tmp >= 0) {
            isSuccess = false;
            break;
        }
    }
    return isSuccess;
}

/**
 *  XSS(크로스사이트 스크립팅)을 검사할 문자열 확인 및 XSS취약한 문자 치환
 */
var fnXSSfilter = function(content) {
	return content.replace(/</g, "&lt;").replace(/>/g, "&gt;");
};

/**
 * XSS(크로스사이트 스크립팅) 문자열로 변환
 * @param content
 * @returns
 */
function fnReplaceHtmlTag(content) {
	content = content + '';
	return content.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}

/**
 * 개행(줄바꿈)문자를 <br>로 치환
 * 
 * @param content
 * @returns
 */
function fnReplaceCarigeToBr(content) {
	return content.replace(/(?:\r\n|\r|\n)/g, '<br />');
}

/**
 * <br> 문자열을 개행(줄바꿈)문자로 치환
 * @param content
 * @returns
 */
function fnReplaceBrToCarige(content) {
	return content.replace(/<br \/\>/g,'\r\n');
}