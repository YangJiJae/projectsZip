/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.exam.fileupload.biz.impl;

import java.io.File;
import java.nio.file.FileSystems;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import kcb.core.config.FTPClientConfig.FtpChannel;
import kcb.core.util.FTPClientUtil;
import kcb.exam.fileupload.biz.FileUploadBiz;
import net.sf.json.JSONObject;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 1. 23.
 */
@Service
public class FileUploadBizImpl implements FileUploadBiz {
	private static final Logger logger = LoggerFactory.getLogger(FileUploadBizImpl.class);
	
	@Autowired
	private FtpChannel ftpChannel;
	
//	@Autowired
//	private RemoteFileTemplate<FTPFile> remoteFileTemplate;
	
	@Autowired
	private FTPClientUtil ftpClientUtil;
	
	
	@Override
	public String singleSave(final MultipartFile multipartFile, String directory) throws Exception {
	    ByteArrayResource resource = new ByteArrayResource(multipartFile.getBytes()){
    		@Override
    		public String getFilename() throws IllegalStateException {
    			return multipartFile.getOriginalFilename();
    		}
    	};
    	
    	String filename = FilenameUtils.getName(resource.getFilename());
		multipartFile.transferTo(new File(directory +"/"+ filename));


		// FTP 송/수신 방법 1		
//		ftpChannel.sendFile(FileSystems.getDefault().getPath(directory, filename).toFile());
//		File receiveFile = ftpChannel.receiveFile("/upload/"+filename);
//		logger.info("receiveFile :: {}", receiveFile.getName());
		
//		List<File> receiveFiles = ftpChannel.receiveFiles("/upload/*");
//		logger.info("receiveFile :: {}", receiveFiles);

		// FTP 송/수신 방법 2 
//		final Message<File> message = MessageBuilder.withPayload(FileSystems.getDefault().getPath(directory, filename).toFile()).build();
//		remoteFileTemplate.send(message, FileExistsMode.REPLACE);
//		
//		final FileOutputStream fis = new FileOutputStream(FileSystems.getDefault().getPath("C:\\projects\\developments\\test\\ftp\\download", filename).toFile());
//		boolean success = remoteFileTemplate.get("/upload/"+filename, new InputStreamCallback() {
//            @Override
//            public void doWithInputStream(InputStream inputStream) throws IOException {
//                FileCopyUtils.copy(inputStream, fis);
//            }
//        });
//        fis.flush();
//        logger.info("success  :: {}", success);
        
		// FTP 송/수신 방법 3
		ftpClientUtil.connect();
		if (ftpClientUtil.login()) {
			
			// 파일 업로드
			ftpClientUtil.sendFile(FileSystems.getDefault().getPath(directory, filename).toFile());
			
			// 파일 다운로드
			File downloadFile = ftpClientUtil.receiveFile(FileSystems.getDefault().getPath("C:\\projects\\test\\ftp\\download", filename).toFile());
			logger.info("downloadFile :: {}", downloadFile.getName());
			
			// 파일 삭제
//			boolean deleted = ftpClientUtil.deleteFile(filename);
//			logger.info("deleted :: {}", deleted);
		}
		ftpClientUtil.logout();
		ftpClientUtil.disconnect();
		
		
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		map.put("file", filename);
    	
    	JSONObject jsonObject = JSONObject.fromObject(map);
    	return jsonObject.toString();
	}
}
