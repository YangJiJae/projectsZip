/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.filter.request;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 설명 : request InputStream을 캐싱해 놓으므로써 읽고 난 후 request body의 파라미터가 사라지는 것을 방지해 준다. 
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 9. 21.
*/
public class MultiReadHttpServletRequestWrapper extends HttpServletRequestWrapper {
	private final Charset encoding;
	private ByteArrayOutputStream cachedBytes;

	public MultiReadHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
		
		String characterEncoding = request.getCharacterEncoding();
        if (StringUtils.isBlank(characterEncoding)) {
            characterEncoding = StandardCharsets.UTF_8.name();
        }
        this.encoding = Charset.forName(characterEncoding);		
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		if (cachedBytes == null) { cacheInputStream(); }
		return new CachedServletInputStream();
	}

	@Override
	public BufferedReader getReader() throws IOException{
		return new BufferedReader(new InputStreamReader(getInputStream(), this.encoding));
	}

    @Override
    public ServletRequest getRequest() {
        return super.getRequest();
    }	
	
	private void cacheInputStream() throws IOException {
	    cachedBytes = new ByteArrayOutputStream();
	    IOUtils.copy(super.getInputStream(), cachedBytes);
	}

	public class CachedServletInputStream extends ServletInputStream {
	    private ByteArrayInputStream input;

	    public CachedServletInputStream() {
	    	input = new ByteArrayInputStream(cachedBytes.toByteArray());
	    }

	    @Override
	    public int read() throws IOException {
	    	return input.read();
	    }

		@Override
		public boolean isFinished() { return false; }

		@Override
		public boolean isReady() { return false; }

		@Override
		public void setReadListener(ReadListener readListener) {}
	}
}
