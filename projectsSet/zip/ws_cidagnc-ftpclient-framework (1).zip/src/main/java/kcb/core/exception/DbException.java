/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.exception;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 24.
 */
public class DbException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private static final String DEFAULT_MESSAGE = "시스템 에러";
	
	private String code;
	private String message;
	
	public DbException() {
		super(DEFAULT_MESSAGE);
	}
	
	public DbException(String message) {
        super(message);
        this.message = message;
    }

	public DbException(String code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }	
	
    public DbException(String message, Throwable cause) {
        super(message, cause);
    }

    public DbException(Throwable cause) {
        super(cause);
    }
    
    public String getCode() {
		return code;
	}
    public String getMessage() {
        return message;
    }    
}
