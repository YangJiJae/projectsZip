/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.aop;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.aspectj.AbstractAspectJAdvice;

/**
 * 설명 : Target 클래스의 특정 메소드의 실행을 무사히 완료한 뒤에 추가할 작업을 정의 할 때 사용합니다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 4. 18.
 */
public class DoAfterReturningMethod implements AfterReturningAdvice {
	private static final Logger logger = LoggerFactory.getLogger("serviceLogger");
	
	@Override
	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		JoinPoint joinPoint = AbstractAspectJAdvice.currentJoinPoint();
		logger.info(":: END - " + joinPoint.getSignature());
    }
}
