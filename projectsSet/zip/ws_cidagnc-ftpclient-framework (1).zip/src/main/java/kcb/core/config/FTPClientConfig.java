/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config;

import java.io.File;
import java.util.List;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.common.LiteralExpression;
import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.file.FileNameGenerator;
import org.springframework.integration.file.filters.AcceptOnceFileListFilter;
import org.springframework.integration.file.remote.RemoteFileTemplate;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.ftp.filters.FtpSimplePatternFileListFilter;
import org.springframework.integration.ftp.gateway.FtpOutboundGateway;
import org.springframework.integration.ftp.inbound.FtpInboundFileSynchronizer;
import org.springframework.integration.ftp.inbound.FtpInboundFileSynchronizingMessageSource;
import org.springframework.integration.ftp.outbound.FtpMessageHandler;
import org.springframework.integration.ftp.session.DefaultFtpSessionFactory;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.scheduling.support.PeriodicTrigger;

import kcb.core.config.properties.ftp.FTPProperties;

/**
 * 설명 : SpringBoot Integration 이용한 FTP Client 설정을 한다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 21.
*/
@Configuration
public class FTPClientConfig {

    @Autowired
    private FTPProperties ftpProperties;	
	
    @Bean
    public SessionFactory<FTPFile> ftpSessionFactory() {
    	DefaultFtpSessionFactory factory = new DefaultFtpSessionFactory ();
    	
        factory.setHost(ftpProperties.getHost());
        factory.setPort(ftpProperties.getPort());
        factory.setUsername(ftpProperties.getUsername());
        factory.setPassword(ftpProperties.getPassword());
        factory.setControlEncoding(ftpProperties.getControlEncoding());
        factory.setClientMode(FTPClient.PASSIVE_LOCAL_DATA_CONNECTION_MODE);

        return new CachingSessionFactory<FTPFile>(factory);
    }
    
    @Bean
    public FtpInboundFileSynchronizer ftpInboundFileSynchronizer() {
        FtpInboundFileSynchronizer fileSynchronizer = new FtpInboundFileSynchronizer(ftpSessionFactory());
        
        fileSynchronizer.setDeleteRemoteFiles(false);
        fileSynchronizer.setRemoteDirectory(ftpProperties.getRemoteDirectory());
        fileSynchronizer.setFilter(new FtpSimplePatternFileListFilter(ftpProperties.getPatternFileListFilter()));
        return fileSynchronizer;
    }    
 
    @Bean(name = PollerMetadata.DEFAULT_POLLER)
    public PollerMetadata defaultPoller() {

        PollerMetadata pollerMetadata = new PollerMetadata();
        pollerMetadata.setTrigger(new PeriodicTrigger(20));
        return pollerMetadata;
    }    
    
    @Bean
    @InboundChannelAdapter(channel = "toftpChannel", autoStartup = "false", poller = @Poller(cron = "0/5 * * * * *", maxMessagesPerPoll = "1"))
    public MessageSource<File> ftpMessageSource() {
        FtpInboundFileSynchronizingMessageSource source = new FtpInboundFileSynchronizingMessageSource(ftpInboundFileSynchronizer());
        
        source.setLocalDirectory(new File(ftpProperties.getLocalDirectory()));
        source.setAutoCreateLocalDirectory(true);
        source.setLocalFilter(new AcceptOnceFileListFilter<File>());
        return source;
    }    
    
    @Bean
    @ServiceActivator(inputChannel = "toftpChannel")
    public MessageHandler toHandler() {
        FtpMessageHandler handler = new FtpMessageHandler(ftpSessionFactory());
        
        handler.setAutoCreateDirectory(true);  
        handler.setRemoteDirectoryExpression(new LiteralExpression(ftpProperties.getRemoteDirectory()));
        handler.setFileNameGenerator(new FileNameGenerator() {
            @Override
            public String generateFileName(Message<?> message) {
                if (message.getPayload() instanceof File) {
                	return ((File) message.getPayload()).getName();
                	
                } else {
                    throw new IllegalArgumentException("File expected as payload.");
                }
            }
        });
        return handler;
    }    
    
    @Bean
    @ServiceActivator(inputChannel = "fromftpChannel")
    public MessageHandler fromHandler() {
        FtpOutboundGateway ftpOutboundGateway = new  FtpOutboundGateway(ftpSessionFactory(), "mget", "payload");
        
        ftpOutboundGateway.setOptions("-R");
        ftpOutboundGateway.setFileExistsMode(FileExistsMode.REPLACE);
        ftpOutboundGateway.setLocalDirectory(new File(ftpProperties.getLocalDirectory()));
        return ftpOutboundGateway;
    }
    
    /**
     * 설명 : 채널을 이용하는 경우
     *
     * @author 양성진 (t17047@koreacb.com)
     * @date 2018. 5. 24.
     */
    @MessagingGateway
    public interface FtpChannel {
    	
        @Gateway(requestChannel = "toftpChannel")
        public void sendFile(File file);
        
        @Gateway(requestChannel = "fromftpChannel")
        public File receiveFile(String remoteFilePath);
        
        @Gateway(requestChannel = "fromftpChannel")
        public List<File> receiveFiles(String remoteDiretory);
    }
    
    /**
     * 설명 : Template를 이용하는 경우
     *
     * @Method : remoteFileTemplate
     * @return
     */
    @Bean
    public RemoteFileTemplate<FTPFile> remoteFileTemplate() {
    	RemoteFileTemplate<FTPFile> remoteFileTemplate = new RemoteFileTemplate<FTPFile>(ftpSessionFactory());
    	
    	remoteFileTemplate.setRemoteDirectoryExpression(new LiteralExpression(ftpProperties.getRemoteDirectory()));
    	remoteFileTemplate.setCharset(ftpProperties.getControlEncoding());
    	remoteFileTemplate.setAutoCreateDirectory(true);
    	remoteFileTemplate.setUseTemporaryFileName(true);
    	
    	return remoteFileTemplate;
    }    
}
