/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.aop;

import org.springframework.aop.ThrowsAdvice;

/**
 * 설명 : AOP 설정에서 포인트 컷 표현식으로 지정된 메소드 실행 후 오류가 발생되면 해당 공통 메소드를 실행한다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 15.
 */
public class DoAfterThrowingExceptionMethod implements ThrowsAdvice {
//	private static final Logger logger = LoggerFactory.getLogger("serviceLogger");
//	
	public void afterThrowing(Throwable ex) throws Throwable {
//		System.out.print("\n");
//		logger.error(ex.getClass() + " :: "+ ex.getMessage());
//		
//		for (int i = 0; i < ex.getStackTrace().length; i++) {
//			logger.error("\t {}", ex.getStackTrace()[i].toString());
//		}
//		System.out.print("\n");
	}
}