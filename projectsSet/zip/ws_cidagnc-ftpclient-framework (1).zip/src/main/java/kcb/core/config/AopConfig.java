/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config;

import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import kcb.core.aop.DoAfterReturningMethod;
import kcb.core.aop.DoAfterThrowingExceptionMethod;
import kcb.core.aop.DoAroundMethod;
import kcb.core.aop.DoBeforeMethod;

/**
 * 설명 : AOP관련하여 설정을 다룬다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 4. 18.
 */
@Configuration
public class AopConfig {
    private static final String AOP_POINTCUT_EXPRESSION = "execution(* kcb..biz.impl.*Impl.*(..))";

	@Bean
	public DoAroundMethod doAroundMethod() {
		return new DoAroundMethod();
	}
	
    @Bean
    public Advisor doBeforeMethodAdvisor() {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(pointcut, new DoBeforeMethod());
    }

    @Bean
    public Advisor doAfterReturningMethodAdvisor() {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(pointcut, new DoAfterReturningMethod());
    }
    
    @Bean
    public Advisor doAroundMethodAdvisor() {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(pointcut, doAroundMethod());
    }  
    
    @Bean
    public Advisor doAfterThrowingExceptionMethodAdvisor() {
        AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
        pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
        return new DefaultPointcutAdvisor(pointcut, new DoAfterThrowingExceptionMethod());
    }    
}
