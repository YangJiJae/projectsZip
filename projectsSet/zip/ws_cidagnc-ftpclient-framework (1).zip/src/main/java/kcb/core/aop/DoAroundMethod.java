/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.aop;

import java.util.Arrays;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

/**
 * 설명 : AOP 설정에서 포인트 컷 표현식으로 지정된 메소드 실행되는 동안 해당 공통 메소드를 실행한다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 15.
 */
@Component
public class DoAroundMethod implements MethodInterceptor {
	private static final Logger logger = LoggerFactory.getLogger(DoAroundMethod.class);
	
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		logger.info("************************************************************");
		logger.info(" - class : " + methodInvocation.getThis().getClass().getName());
		logger.info(" - method : " + methodInvocation.getMethod().getName());	    
		logger.info(" - method arguments : " + Arrays.toString(methodInvocation.getArguments()));
	    
	    final StopWatch sw = new StopWatch();
	    try {
	    	sw.start();
	    	
	    	// 대상 메서드 호출
	    	Object result = methodInvocation.proceed();
	    	return result;
	      
	    } catch (IllegalArgumentException e) {
	    	throw e;
	    	
	    } finally {
			sw.stop();			
			logger.info(" - time : " + sw.getTotalTimeMillis()/1000.0 + "초");
			logger.info("************************************************************");	    	
	    }
	}
}