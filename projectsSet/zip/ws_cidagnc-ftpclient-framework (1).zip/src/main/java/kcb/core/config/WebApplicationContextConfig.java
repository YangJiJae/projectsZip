/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.MultipartConfigElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.multipart.support.MultipartFilter;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.view.BeanNameViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import kcb.core.filter.request.MultiReadHttpServletRequestFilter;
import kcb.core.filter.xss.XSSFilter;
import kcb.core.interceptor.RequestProcessingTimeInterceptor;

/**
 * 설명 : SpringBoot에서 Web 환경구성에 필요한 사항들을 정의하고 설정한다. 이에 대한 Java Configuration 클래스
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 7. 6.
 */
@Configuration
public class WebApplicationContextConfig extends WebMvcConfigurerAdapter {
    private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {
			"classpath:/META-INF/resources/", 
			"classpath:/resources/", 
			"classpath:/static/", 
			"classpath:/public/",
			"classpath:/META-INF/resources/webjars/" 
	};	
	
	@Autowired private LocaleChangeInterceptor localeChangeInterceptor;
	@Autowired private RequestProcessingTimeInterceptor requestProcessingTimeInterceptor;
	
	
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**").addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
		registry.addResourceHandler("swagger-ui.html").addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(localeChangeInterceptor).addPathPatterns("/**");
		registry.addInterceptor(requestProcessingTimeInterceptor).addPathPatterns("/**");
	}	
	
	@Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		super.configureMessageConverters(converters);
		
		converters.add(mappingJackson2HttpMessageConverter());
    	converters.add(formHttpMessageConverter());
	    converters.add(stringHttpMessageConverter());
    }	
	
	@Bean
	public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		
		ObjectMapper objectMapper = new ObjectMapper(); 
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); 
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false); 
		objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		converter.setObjectMapper(objectMapper); 	
		
	    List<MediaType> supportedMediaTypes = new ArrayList<MediaType>();
	    supportedMediaTypes.add(new MediaType("application","json", Charset.forName("UTF-8")));
	    supportedMediaTypes.add(new MediaType("text","html", Charset.forName("UTF-8")));
	    converter.setSupportedMediaTypes(supportedMediaTypes);		
		return converter;
	}	
		
	@Bean
	public FormHttpMessageConverter formHttpMessageConverter() {
		FormHttpMessageConverter formHttpMessageConverter = new FormHttpMessageConverter();
		return formHttpMessageConverter;
	}	
	
	@Bean
	public StringHttpMessageConverter stringHttpMessageConverter() {
		return new StringHttpMessageConverter(Charset.forName("UTF-8"));
	}	
	
	@Bean
	public FilterRegistrationBean characterFilterRegistrationBean() {
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();

		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding("UTF-8");
		characterEncodingFilter.setForceEncoding(true);		
		registrationBean.setFilter(characterEncodingFilter);
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	} 
	
	@Bean
	public FilterRegistrationBean multiReadHttpServletRequestFilter() {
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();

		registrationBean.setFilter(new MultiReadHttpServletRequestFilter());
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	}
	
	@Bean
	public FilterRegistrationBean xssFilter() {
		FilterRegistrationBean registrationBean = new FilterRegistrationBean();

		registrationBean.setFilter(new XSSFilter());
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	}
	
	@Bean
	public ViewResolver viewResolver() {
		BeanNameViewResolver resolver = new BeanNameViewResolver();
		resolver.setOrder(1);
		return resolver;
	}

    @Bean
    public ViewResolver jspViewResolver() {
    	InternalResourceViewResolver resolver = new InternalResourceViewResolver();
    	
    	resolver.setViewClass(JstlView.class);
        resolver.setPrefix("/WEB-INF/jsp/");
        resolver.setSuffix(".jsp");
        resolver.setOrder(2);
        return resolver;
    }
	
    @Bean(name="jsonView")
    public View jsonView() {
        MappingJackson2JsonView view = new MappingJackson2JsonView();
        view.setContentType("application/json; charset=utf-8");
        view.setPrettyPrint(true);
        
        return view;
    }	
    
	@Bean(name="multipartResolver")
	public MultipartResolver multipartResolver() throws IOException {
		CommonsMultipartResolver multipartResolver  = new CommonsMultipartResolver();
		
		multipartResolver.setDefaultEncoding("utf-8");
		multipartResolver.setMaxUploadSize(-1);
	    return multipartResolver;
	}
	@Bean
    MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        factory.setMaxFileSize("200MB");
        factory.setMaxRequestSize("200MB");
        return factory.createMultipartConfig();
    }	
    @Bean
    public FilterRegistrationBean multipartFilterRegistrationBean() {
        final MultipartFilter multipartFilter = new MultipartFilter();
        final FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean(multipartFilter);
        
        filterRegistrationBean.addInitParameter("multipartResolverBeanName", "commonsMultipartResolver");
        return filterRegistrationBean;
    }    
}