/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.util;

import java.io.*;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.ThreadPoolExecutor;
//import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * 설명 : 파일 유틸
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 1. 22.
 */
@Component
@Scope("singleton")
public class FileUtil {
	
	/**
	* @Param String filePath : 존재여부를 검사할 디렉토리경로명
	* 
	* @return 파일디렉토리 존재여부 체크하고 존재하지 않으면 디렉토리를 생성한다.
	 * @throws Exception 
	*/
	public void checkDirectoryPath(final String filePath) throws Exception {
		File ckPath = new File(filePath);
		
		if(!ckPath.isDirectory()) { 
			ckPath.mkdirs(); 
		}
	}	
	
	/**
	* @Param String filePath : 존재여부를 검사할 디렉토리경로명
	* 
	* @return 파일디렉토리 존재여부 체크하고 존재하지 않으면 디렉토리를 생성한다.
	*/
	public void checkFilePath(final String filePath, final String fileName) throws Exception {
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		
		if (Files.notExists(path, new LinkOption[]{LinkOption.NOFOLLOW_LINKS})) {
			newFile(path);
		}
	}	
	
	/**
	* @Param String filePath : 재명명할 대상 파일경로명
	* 
	* @return 파일이름 재명명 시킨다.
	 * @throws Exception 
	*/
	public void checkRenameFile(final String filePath, final String fileName) throws Exception {
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
			
		if (Files.exists(path, new LinkOption[]{LinkOption.NOFOLLOW_LINKS})) {
			Files.move(path, path.resolveSibling("_" + fileName));
		}
	}

	/**
	* @Param Path targetPath : 새로운 파일경로
	* 
	* @return  새로운 파일을 생성한다.
	*/
	public void newFile(final Path path) throws Exception {
		Files.createFile(path);
	}	
	
	/**
	* @Param String filePath : 새로운 파일경로명
	* @Param String fileName : 새로운 파일명
	* 
	* @return  새로운 파일을 생성하고 성공시 1을 리턴한다.
	 * @throws Exception 
	*/
	public int newFile(final String filePath, final String fileName) throws Exception {
		int result = 0;
		
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		Files.createFile(path);
			
		return result++;
	}

	/**
	* @Param String filePath : 새로운 파일경로명
	* @Param String fileName : 새로운 파일명
	* @Param String data : 새로운 파일에 write 할 데이터
	* @Param StandardOpenOption standardOpenOption : 표준열기 옵션
	* 
	* @return  새로운 파일을 생성하고 성공시 1을 리턴한다.
	 * @throws Exception 
	*/	
	public int newFile(final String filePath, final String fileName, final String data) throws Exception {
		int result = 0;
		
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		Charset charset = Charset.forName("UTF-8");
			
		try (BufferedWriter writer = Files.newBufferedWriter(path, charset, StandardOpenOption.CREATE , StandardOpenOption.WRITE)) {
			writer.write(data);
			writer.close();
			
			return result++;
		}
	}
	
	/**
	* @Param String filePath : 새로운 파일경로명
	* @Param String fileName : 새로운 파일명
	* @Param String data : 새로운 파일에 write 할 데이터
	* @Param StandardOpenOption standardOpenOption : 표준열기 옵션
	* 
	* @return  새로운 파일을 생성하고 성공시 1을 리턴한다.
	 * @throws Exception 
	*/	
	public int newFile(final String filePath, final String fileName, final byte[] bytes) throws Exception {
		int result = 0;
		
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		Files.write(path, bytes, StandardOpenOption.CREATE , StandardOpenOption.WRITE);
			
		return result++;
	}	
	
	/**
	* @Param String filePath : 새로운 파일경로명
	* @Param String fileName : 새로운 파일명
	* @Param ByteBuffer bytes : 새로운 파일에 write 할 데이터

	* @return  새로운 파일을 생성한다.
	 * @throws Exception 
	*/	
	public int newFile(final String filePath, final String fileName, final ByteBuffer byteBuffer) throws Exception {
		int result = 0;

		Path path = FileSystems.getDefault().getPath(filePath, fileName);
			
		try (FileChannel fileChannel = (FileChannel)(Files.newByteChannel(path, EnumSet.of(StandardOpenOption.CREATE , StandardOpenOption.WRITE)))) {
			fileChannel.write(byteBuffer);
			fileChannel.close();
			
			return result++;
		}
	}	
	
	/**
	* @Param String filePath : 새로운 파일경로명
	* @Param String fileName : 새로운 파일명
	* @Param ByteBuffer bytes : 새로운 파일에 write 할 데이터
	* 
	* @return  새로운 파일을 생성한다.
	 * @throws Exception 
	*/	
/*
	public int newFileExecutor(String filePath, String fileName, ByteBuffer bytes) throws Exception {
		String mFilePath;
		String mFileName;
		Path path;
		AtomicInteger fileindex;
		ThreadPoolExecutor taskExecutor;		
		AsynchronousFileChannel outputfile;
		List<Future<Integer>> futures;
		
		try {
			mFilePath		= filePath;
			mFileName		= fileName;
			path = FileSystems.getDefault().getPath(mFilePath, mFileName);
			
			fileindex = new AtomicInteger(0);
			taskExecutor = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
			
			outputfile = AsynchronousFileChannel.open(
							path,new HashSet<StandardOpenOption>(Arrays.asList(StandardOpenOption.CREATE , StandardOpenOption.WRITE)), taskExecutor);
			
			futures = new ArrayList<>();
			futures.add(outputfile.write(bytes, fileindex.byteValue()));

			outputfile.close();
			taskExecutor.shutdown();
			
		} catch (Exception e) {
			throw new CommonException(e);
		} 
		return futures.size();
	}	
*/
	public int newFileExecutor(final String filePath, final String fileName, final ByteBuffer byteBuffer) throws Exception {
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
					
		AtomicInteger fileindex = new AtomicInteger(0);
		ExecutorService taskExecutor = Executors.newCachedThreadPool();
		
		try (AsynchronousFileChannel outputfile = AsynchronousFileChannel.open(
						path,new HashSet<StandardOpenOption>(Arrays.asList(StandardOpenOption.CREATE , StandardOpenOption.APPEND, StandardOpenOption.WRITE)), taskExecutor)) {
		
			List<Future<Integer>> futures = new ArrayList<>();
			futures.add(outputfile.write(byteBuffer, fileindex.byteValue()));

			outputfile.close();
			taskExecutor.shutdown();
			
			return futures.size();
		}
	}	

	
	/**
	* @Param String filePath : 파일경로명
	* @Param String fileName :  파일명

	* @return  읽어들인 ByteBuffer bytes
	 * @throws Exception 
	*/	
	public ByteBuffer readFile(final String filePath, final String fileName) throws Exception {
		ByteBuffer result = null;

		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		
		ExecutorService taskExecutor = Executors.newCachedThreadPool();
		try (AsynchronousFileChannel asynchronousFileChannel = 
				AsynchronousFileChannel.open(path, new HashSet<StandardOpenOption>(Arrays.asList(StandardOpenOption.READ, StandardOpenOption.DELETE_ON_CLOSE)), taskExecutor)) {	
			
			result = ByteBuffer.allocateDirect((int) asynchronousFileChannel.size());
			asynchronousFileChannel.read(result, 0);
			result.flip();
			
			return result;
		}
	}		

	
	/**
	* @Param String source : 원본 파일경로명
	* @Param String target : 복사할 파일경로명
	* 
	* @return  파일을 복사한다.
	 * @throws IOException 
	*/	
	public void copyFile(final String source, final String target) throws Exception {
		Path in = FileSystems.getDefault().getPath(source);
		Path out  = FileSystems.getDefault().getPath(target);
			
		Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES, LinkOption.NOFOLLOW_LINKS);
	}	

	/**
	* @Param Path source : 원본 파일 path
	* @Param Path target : 복사할 파일 path
	* 
	* @return  파일을 복사한다.
	 * @throws Exception 
	*/		
	public void copyFile(final Path source, final Path target) throws Exception {
		Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES, LinkOption.NOFOLLOW_LINKS);
	}	
	
	/**
	* @Param String source : 원본 파일경로명
	* @Param String target : 이동할 파일경로명
	* 
	* @return  파일을 이동한다.
	 * @throws Exception 
	*/		
	public void moveFile(final String source, final String target) throws Exception {
		Path in  = Paths.get(source);
		Path out = Paths.get(target);
		
		Files.move(in, out, StandardCopyOption.REPLACE_EXISTING);
	}
	public void moveFile(final Path source, final Path target) throws Exception {
		Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
	}	

	/**
	* @Param String filePath : 삭제할 파일경로명
	* 
	* @return  파일을 삭제한다.  (단, 경로상의 파일이 존재할 경우만 삭제한다.)
	 * @throws Exception 
	*/			
	public void deleteFile(final String filePath) throws Exception {
		Path path = FileSystems.getDefault().getPath(filePath);
		Files.deleteIfExists(path);
	}
	
	/**
	* @Param String filePath : 읽을 파일경로명
	* 
	* @return  라인단위 Data를 읽어들여 List에 담아 리턴한다. 
	 * @throws Exception 
	*/	
	public List<String> getLines(final String filePath) throws Exception {
		Path path = FileSystems.getDefault().getPath(filePath);
		
		try (BufferedReader reader = Files.newBufferedReader(path, Charset.defaultCharset())) {
			List<String> list 	= new Vector<String>();
			String data	= new String();
			
			while(true) {
				data = reader.readLine();
				
				if(data == null) {
					break;
				}
				list.add(data);
			}
			reader.close();
			return list;
		}
	}


	public static void main(String args[]) throws Exception  {
/*		
		String filePath = "D:/test";
		String fileName ="test.txt";
		String data = "1";
		int result =0;
			
		StopWatch sw = new StopWatch();
		sw.start();
		
		for (int i=0; i< 10000; i++) {
			result += FileUtil.getInstance().newFileExecutor(filePath, fileName+"_"+i, ByteBuffer.wrap(data.getBytes()));
		}
		sw.stop();
		
		System.out.println("처리건수 합 = "+result);
		System.out.println("처리시간: " + sw.getTotalTimeMillis() / 1000.0 + "초");
		
		//FileUtil.getInstance().newFileExecutor(filePath, fileName, ByteBuffer.wrap(data.getBytes()));
		FileUtil.getInstance().readFile(filePath, fileName);
*/
		String filePath = "D:\\3. devTest\\batch\\Release\\SocketRelay.exe";
		Path path = FileSystems.getDefault().getPath(filePath);
		
		System.out.println("path.getFileName = "+ path.getFileName());
		System.out.println("path.toAbsolutePath = "+ path.toAbsolutePath());
	}

}