/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import kcb.core.config.properties.ftp.FTPProperties;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 6. 11.
*/
@Component
public class FTPClientUtil {
	private static final Logger logger = LoggerFactory.getLogger(FTPClientUtil.class);
	private FTPClient ftpClient;
	
	@Autowired
	private FTPProperties ftpProperties;
	
	@PostConstruct
	private void init() {
		ftpClient = new FTPClient();
		ftpClient.setControlEncoding("euc-kr");
	}
	
	
	public void connect() {
		try {
			ftpClient.connect(ftpProperties.getHost(), ftpProperties.getPort());
			int reply = ftpClient.getReplyCode();

			if(FTPReply.isPositiveCompletion(reply) == false) {
				ftpClient.disconnect();
			}
			ftpClient.enterLocalPassiveMode();

		} catch(Exception e) {
			if(ftpClient.isConnected() == true) {
				try{
					ftpClient.disconnect();

				} catch(IOException f){}
			}
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
	}	
	
	public boolean login() {
		try{
			if(ftpClient.isConnected() == true) {
				return ftpClient.login(ftpProperties.getUsername(), ftpProperties.getPassword());
			}

		}catch(Exception e){
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return false;
	}
	
	public boolean logout() {
		try{
			return ftpClient.logout();

		} catch(Exception e) {
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return false;
	}
	
	public boolean sendFile(final File file) {
		return sendFile(file, false);
	}
	public boolean sendFile(final File file, final boolean appended) {
		boolean flag = false;

		try (InputStream input = new FileInputStream(file)) {
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			
			if (appended) {
				flag = ftpClient.appendFile(ftpProperties.getRemoteDirectory()+"/"+file.getName(), input);
				
			} else {
				flag = ftpClient.storeFile(ftpProperties.getRemoteDirectory()+"/"+file.getName(), input);
			}
			input.close();
			
		} catch (Exception e) {
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return flag;
	}	
	
	public File receiveFile(final File file) {
		try (OutputStream output = new FileOutputStream(file)) {
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			boolean flag = ftpClient.retrieveFile(ftpProperties.getRemoteDirectory()+"/"+file.getName(), output);
			
			output.flush();
			output.close();
			
			if(flag == true) {
				return file;
			}
			
		} catch (Exception e) {
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return null;
	}	
	
	public boolean deleteFile(final String target) {
		boolean deleted = false; 
		
		try {
			deleted = ftpClient.deleteFile(ftpProperties.getRemoteDirectory()+"/"+target);
			
		} catch (Exception e) {
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
		return deleted;
	}
	
	public void cd(String path) {
		try{
			ftpClient.changeWorkingDirectory(path);

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void disconnect() {
		try{
			ftpClient.disconnect();

		}catch(Exception e){
			logger.error("{}", ExceptionUtils.getStackTrace(e));
		}
	}	
}
