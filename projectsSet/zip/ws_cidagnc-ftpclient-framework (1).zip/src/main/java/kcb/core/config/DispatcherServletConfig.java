/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config;

import javax.servlet.MultipartConfigElement;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * 
 * 설명 : 클라이언트 요청을 핸들링하기 위해 앞단에서 컨트롤 하기 위해 존재한다.
 *        클라이언트로 부터 오는 URL이 무엇이되던, 이 서블릿은 컨트롤러에 요청 객체로 넘겨주기 전에 클라이언트의 요청을 가로챈다. 이와 관련된 Configuration 이다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 4. 18.
 */
@Configuration
public class DispatcherServletConfig {
	
	@Bean
	public DispatcherServlet dispatcherServlet() {
	    return new DispatcherServlet();
	}	
	
    @Bean 
    public ServletRegistrationBean dispatcherRegistration(DispatcherServlet dispatcherServlet, MultipartConfigElement multipartConfig) { 
        ServletRegistrationBean registration = new ServletRegistrationBean(dispatcherServlet); 
        
        registration.addUrlMappings("/"); 
        registration.setMultipartConfig(multipartConfig);
        registration.setLoadOnStartup(1);
        registration.setAsyncSupported(true); 
        return registration; 
    } 
}