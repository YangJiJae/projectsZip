/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * 설명 : URL 호출 및 응답시 걸린 시간을 로깅처리 한다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 7. 6.
 */
@Component
public class RequestProcessingTimeInterceptor extends HandlerInterceptorAdapter {
	private static final Logger logger = LoggerFactory.getLogger("systemLogger");

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		long startTime = System.currentTimeMillis();
		
		logger.info("preHandle, Request URL::" + request.getRequestURL().toString()+ ":: Start Time = " + startTime);
		request.setAttribute("startTime", startTime);
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		long startTime = (Long) request.getAttribute("startTime");
		logger.info("afterCompletion, Request URL::" + request.getRequestURL().toString() + ":: End Time = " + System.currentTimeMillis());
		
		long kakenTime = System.currentTimeMillis() - startTime;
		logger.info("Request URL::" + request.getRequestURL().toString() + ":: Time Taken=" + kakenTime/1000.0 + "초");
		
		super.afterCompletion(request, response, handler, ex);
	}
}
