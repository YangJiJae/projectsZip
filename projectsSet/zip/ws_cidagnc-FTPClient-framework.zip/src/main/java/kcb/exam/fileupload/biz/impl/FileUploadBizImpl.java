/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.exam.fileupload.biz.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.integration.file.remote.InputStreamCallback;
import org.springframework.integration.file.remote.RemoteFileTemplate;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import kcb.core.config.FTPClientConfig.FtpChannel;
import kcb.core.util.FileUtil;
import kcb.exam.fileupload.biz.FileUploadBiz;
import net.sf.json.JSONObject;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 1. 23.
 */
@Service
public class FileUploadBizImpl implements FileUploadBiz {
	private static final Logger logger = LoggerFactory.getLogger(FileUploadBizImpl.class);
	
	@Autowired
	private FtpChannel ftpChannel;
	
	@Autowired
	private RemoteFileTemplate<FTPFile> remoteFileTemplate;
	
	
	@Override
	public String singleSave(final MultipartFile multipartFile, String directory) throws Exception {
	    ByteArrayResource resource = new ByteArrayResource(multipartFile.getBytes()){
    		@Override
    		public String getFilename() throws IllegalStateException {
    			return multipartFile.getOriginalFilename();
    		}
    	};
    	
    	String filename = FilenameUtils.getName(resource.getFilename());
		multipartFile.transferTo(new File(directory +"/"+ filename));


		// FTP 송/수신 방법 1		
//		ftpChannel.sendFile(FileSystems.getDefault().getPath(directory, filename).toFile());
//		File receiveFile = ftpChannel.receiveFile("/upload/"+filename);
//		List<File> receiveFiles = ftpChannel.receiveFiles("/upload/*");
//		logger.info("receiveFile :: {}", receiveFile.getName());

		// FTP 송/수신 방법 2 
		final Message<File> message = MessageBuilder.withPayload(FileSystems.getDefault().getPath(directory, filename).toFile()).build();
		remoteFileTemplate.send(message, FileExistsMode.REPLACE);
		
		final FileOutputStream fis = new FileOutputStream(FileSystems.getDefault().getPath("C:\\projects\\developments\\test\\ftp\\download", filename).toFile());
		boolean success = remoteFileTemplate.get("/upload/"+filename, new InputStreamCallback() {
            @Override
            public void doWithInputStream(InputStream inputStream) throws IOException {
                FileCopyUtils.copy(inputStream, fis);
            }
        });
        fis.flush();
        logger.info("success  :: {}", success);
        
		
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		map.put("file", filename);
    	
    	JSONObject jsonObject = JSONObject.fromObject(map);
    	return jsonObject.toString();
	}
}
