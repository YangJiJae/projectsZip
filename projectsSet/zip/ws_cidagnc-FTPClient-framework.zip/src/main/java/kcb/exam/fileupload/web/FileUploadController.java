/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.exam.fileupload.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import kcb.core.util.FileUtil;
import kcb.exam.fileupload.biz.FileUploadBiz;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 1. 23.
 */
@Controller
@RequestMapping(value="/exam")
public class FileUploadController {

	@Autowired
	private FileUploadBiz fileUploadBiz;	
	
	@Autowired
	private FileUtil fileUtil;
	
	
    @RequestMapping(value="/singleUpload.do")
    public String singleUpload() {
    	return "exam/fileupload/singleUpload";
    }
   
    
    @RequestMapping(value="/singleSave.do", method=RequestMethod.POST)
    public @ResponseBody String singleSave(HttpServletRequest request, @RequestParam("file") MultipartFile multipartFile) throws Exception {

    	String directory = request.getServletContext().getRealPath("/upload");
		fileUtil.checkDirectoryPath(directory);
    	
    	if (!multipartFile.isEmpty()) {
            try {
            	String result = fileUploadBiz.singleSave(multipartFile, directory);
            	return "You have successfully uploaded. " + result;
                
            } catch (Exception e) {
                return "You failed to upload " + e.getMessage();
            }
        } else {
            return "Unable to upload. File is empty.";
        }
    }   
}
