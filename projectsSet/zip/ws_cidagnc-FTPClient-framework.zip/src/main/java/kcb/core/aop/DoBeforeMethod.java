/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.aop;

import java.lang.reflect.Method;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.aspectj.AbstractAspectJAdvice;

/**
 * 설명 : target의 특정 메소드를 실행하기 전에 어떠한 일을 추가하고 싶을 경우에 사용합니다.
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 4. 18.
 */
public class DoBeforeMethod implements MethodBeforeAdvice {
	private static final Logger logger = LoggerFactory.getLogger("serviceLogger");
	
	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		JoinPoint joinPoint = AbstractAspectJAdvice.currentJoinPoint();
		logger.info(":: START - " + joinPoint.getSignature());
	}
}