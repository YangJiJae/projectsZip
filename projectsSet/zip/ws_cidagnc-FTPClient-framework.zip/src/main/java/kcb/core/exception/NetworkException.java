/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.exception;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 24.
 */
public class NetworkException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private String code;
	private String message;
	
	public NetworkException(String message) {
        super(message);
        this.message = message;
    }

	public NetworkException(String code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }
	
	public NetworkException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.message = message;
    }	
	
    public NetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public NetworkException(Throwable cause) {
        super(cause);
    }
    
    public String getCode() {
		return code;
	}
    public String getMessage() {
        return message;
    }    
}
