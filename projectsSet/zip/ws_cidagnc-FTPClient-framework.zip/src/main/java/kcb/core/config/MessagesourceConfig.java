/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * 
 * 설명 : 국제화 서비스를 위한 MessageSource 설정한다. 2가지 경우로 설정할 수 있다. 
 *        파일(ex: message.properties), DB형태 모두 설정 가능하다.  
 *
 * @author 양성진 (t17047@koreacb.com)
 * @date 2017. 4. 18.
 */
@Configuration
public class MessagesourceConfig  {	
    static String[] messageProperties = new String[] {"messages/messages", "messages/validations/validations"};
	
	@Value("${properties.refresh.delay.time}")
	private int refreshDelayTime;    
    
    @Bean(name="messageSource")
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        
        messageSource.setBasenames(messageProperties);
        messageSource.setUseCodeAsDefaultMessage(true);
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setCacheMillis(refreshDelayTime);        
        
        return messageSource;
    }
    
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor(){
        LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
        
        localeChangeInterceptor.setParamName("lang");
        return localeChangeInterceptor;
    }    
    
    @Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();

		sessionLocaleResolver.setDefaultLocale(Locale.KOREAN);		
		return sessionLocaleResolver;
	}    
    
    @Bean(name="validator")
    public LocalValidatorFactoryBean validator() {
    	LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
    	
    	validator.setValidationMessageSource(messageSource());
    	return validator;
    }
}
