/**
  * Copyright (c) 2017 KCB.
  * All right reserved.
  *
  * This software is the confidential and proprietary information of KCB.
  * You shall not disclose such Confidential Information and
  * shall use it only in accordance with the terms of the license agreement
  * you entered into with KCB.
 */
package kcb.core.config.properties.ftp;

import javax.annotation.PostConstruct;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * @author 양성진 (t17047@koreacb.com)
 * @date 2018. 5. 18.
*/
@Configuration
@ConfigurationProperties(prefix=FTPProperties.PREFIX)
@Data
public class FTPProperties {
	public static final String PREFIX = "springboot.ftp.client";
	
    private String host;
    private String username;
    private String password;
    
    @Min(0) @Max(65535)
    private int port;
    private String controlEncoding;
    private String localDirectory;
    private String remoteDirectory;
    private String patternFileListFilter;
    
    @PostConstruct
    public void init() {
        if (port == 0) {
            port = 21;
        }
    }    
}
